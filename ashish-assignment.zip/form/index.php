<?php
session_start();
include("database.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    if (empty($_POST['fullname']) || empty($_POST['email']) || empty($_POST['password'])) {
        
        echo "Please fill all the required details";
       
    } else {

        $fullname = $_POST['fullname'];
        $email = $_POST['email'];
        $password = $_POST['password'];

        
        $query = "INSERT INTO userlogin (username, email, password) VALUES ('$fullname', '$email', '$password')";

        
        if(mysqli_query($conn, $query)){
            header("Location: successful.php");
            exit;
        } 
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form-php</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    
    <div class="form-container">
        <form action="" method="post">
            <label for="fullname">Name: </label>
            <input type="text" name="fullname"><br><br>

            <label for="email">E-mail: </label>
            <input type="text" name="email"><br><br>

            <label for="password">Password: </label>
            <input type="password" name="password"><br><br>

            <input id="btn" type="submit">
            <br><br>
            
        </form>
    </div>
</body>

</html>